CopyBuffalo OCR experiment — 2026-10-11

This is a standalone, local-only prototype. It does not reference the WPF project, clipboard,
history, registry, desktop capture, mouse or keyboard. All input PNGs are synthetic and have
ground truth in corpus/manifest.json. No OCR endpoint or upload is used.

Approved sources:
- https://github.com/siska-tech/pure-onnx-ocr/tree/59a6c2c33c72e4dc8e7e5500f544d6674b0e6643 (0.3.1)
- https://crates.io (exact transitive versions/checksums in probe/Cargo.lock; tract-onnx 0.23.8)
- https://huggingface.co/PaddlePaddle/PP-OCRv5_mobile_det_onnx/tree/e6f4fa85f00e168c862bc462aebca69eef9b3d3d
- https://huggingface.co/PaddlePaddle/cyrillic_PP-OCRv5_mobile_rec_onnx/tree/2cef88145434beb8afa9dd82d77d799eb1ad7b29

Requirements: Windows x64, PowerShell 7 (pwsh), installed Rust >=1.91 with the MSVC toolchain,
Python 3 with stdlib only, installed Segoe UI/Consolas fonts and Windows OCR languages ru/en-US.
Tested with Windows 11 22631, Rust/Cargo 1.97.1 and Python 3.10.11. Windows OCR is accessed in
Windows PowerShell 5.1 because its built-in WinRT projections are available there.

From this directory:

```powershell
pwsh -NoProfile -NonInteractive -File .\Setup-Pinned.ps1
pwsh -NoProfile -NonInteractive -File .\Run-Benchmark.ps1
```

Setup downloads the pinned sources/models and builds a separate console executable, using a
project-local Cargo cache/target/temp directory and two compiler jobs at BelowNormal priority.
It installs no toolchain, does not change protection or execution policy, verifies model/archive
SHA256, and builds with --locked. Initial compilation took 7m26s; it is not an OCR timing.
If copybuffalo-ocr-probe.exe is already built at target/release/, only Run-Benchmark.ps1 is needed.

Run uses fresh hidden processes for each image and each engine, a deterministic shuffled corpus,
and alternating paired engine order. Both children have BelowNormal priority and affinity 0xF000
(four of the sixteen logical CPUs). pure-onnx-ocr also uses inference_threads(4), batch size 1,
default detector parameters (long side 960, threshold .3/.6, unclip 1.5), no orientation classifiers,
no warmup, and the unmodified upstream pipeline. It uses the supplied inference.yml dictionary
and preprocessing. Native OCR uses en-US for English and ru-RU for Russian/mixed cases.

Each fresh process loads one engine, processes one PNG five times and exits. First inference
includes image decoding and initial plans; the four repeats reuse the same engine/plans and also
decode the same PNG. Cold means a fresh process/engine, not an emptied OS file cache. The
full-process startup-to-first-result measurement includes the PowerShell wrapper for Windows,
so use load/first/warm measurements to compare engine latency.

Outputs: results/windows.json, results/pure.json (raw text, geometry, iterations, timing and RAM);
results/scored.json and results/per-case.csv (scores). score.py runs assert-based checks for
insertion/deletion/substitution, missing lines, order inversion and native word geometry.

CER is case-sensitive Levenshtein distance / ground-truth Unicode code points after NFC and
whitespace normalization. Visually identical Latin/Cyrillic letters are distinct. Raw CER uses
the engine's own returned line order. Content CER maps regions/words to ground-truth boxes and
orders fragments within each line by X; it is diagnostic and does not change raw OCR output.
Native words are used for geometry because native lines can span or split expected lines.
Matching requires >=35% detected-region area overlap. Missing lines have no matching region;
character/word deletions are Levenshtein deletion counts within matched ground-truth lines.
Column ground truth reads the left column top-to-bottom, then the right column.

RAM is full child-process peak working set (OS counter) and peak sampled private bytes, sampled
every 20ms and at output events. Native results also include in-process memory snapshots.
The native peak includes PowerShell/WinRT wrapper overhead; these are not marginal RAM costs
inside CopyBuffalo. Background workloads remain running, and the CPU limit was deliberate.
No GPU benchmark, real screenshots, live integration, installer or clipboard tests were performed.
