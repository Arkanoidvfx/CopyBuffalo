param([ValidateSet('Both','Windows','Pure')][string]$Engine='Both')
$ErrorActionPreference='Stop'
$studyPath=$PSScriptRoot
[System.Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
$env:TEMP=Join-Path $studyPath 'temp';$env:TMP=$env:TEMP
New-Item -ItemType Directory -Path $env:TEMP -Force | Out-Null
$gpu=& nvidia-smi --query-gpu=name,memory.total,memory.used,memory.free,utilization.gpu --format=csv,noheader,nounits
$gpu | Set-Content -LiteralPath (Join-Path $studyPath 'gpu-before.txt')
& nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,noheader,nounits | Set-Content -LiteralPath (Join-Path $studyPath 'gpu-processes-before.txt')
& (Join-Path $studyPath 'Generate-Corpus.ps1')
& python (Join-Path $studyPath 'benchmark.py') --engine $Engine.ToLowerInvariant()
if ($LASTEXITCODE -ne 0) {throw 'Benchmark failed'}
& python (Join-Path $studyPath 'score.py')
if ($LASTEXITCODE -ne 0) {throw 'Scoring failed'}
