$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$out = Join-Path $PSScriptRoot 'corpus'
New-Item -ItemType Directory -Path $out -Force | Out-Null
$texts = [ordered]@{
    ru = @('Буфер обмена: история скриншотов', 'Сохранить изображение в папку', 'Съешь ещё этих мягких булок.', 'Ёжик, подъезд, щука и большой файл', 'Проверка: 0123456789; цена 1250 руб.', 'Путь: D:\Projects\CopyBuffalo\test.png')
    en = @('Clipboard history and screenshots', 'Save the image to a local folder', 'The quick brown fox jumps over the lazy dog.', 'Settings, search and pinned items', 'Check: 0123456789; price USD 1250.', 'Path: D:\Projects\CopyBuffalo\test.png')
    mixed = @('CopyBuffalo: история clipboard', 'Save PNG в папку D:\Screenshots', 'Русский текст and English words', 'Ошибка ERROR: файл image_2026.png', 'Проверка check: 0123456789; 1250 руб.', 'Ctrl+V — вставить; Win+V — history')
}
$cases = [System.Collections.Generic.List[object]]::new()
foreach ($lang in $texts.Keys) {
    foreach ($family in @('Segoe UI', 'Consolas')) {
        foreach ($px in @(11, 18)) {
            foreach ($theme in @('light', 'dark')) {
                $id = '{0}_{1}_{2}_{3}' -f $lang,($family -replace ' ', ''),$px,$theme
                $bitmap = [System.Drawing.Bitmap]::new(960, 320)
                $bitmap.SetResolution(96,96)
                $g = [System.Drawing.Graphics]::FromImage($bitmap)
                $bg = if ($theme -eq 'light') {'#FAFAFA'} else {'#202124'}
                $fg = if ($theme -eq 'light') {'#202124'} else {'#E8EAED'}
                $g.Clear([System.Drawing.ColorTranslator]::FromHtml($bg))
                $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
                $font = [System.Drawing.Font]::new($family, $px, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Pixel)
                if ($font.Name -ne $family) { throw "Font substitution: $family -> $($font.Name)" }
                $brush = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml($fg))
                $lines = @()
                for ($i=0; $i -lt $texts[$lang].Count; $i++) {
                    $text = $texts[$lang][$i]; $x=24; $y=24 + $i*42
                    $size = $g.MeasureString($text,$font,1000,[System.Drawing.StringFormat]::GenericTypographic)
                    if ($x+$size.Width -ge $bitmap.Width) { throw "Text clipped: $id" }
                    $g.DrawString($text,$font,$brush,[System.Drawing.PointF]::new($x,$y),[System.Drawing.StringFormat]::GenericTypographic)
                    $lines += @{text=$text; box=@($x,$y,[double]$size.Width,[double]$size.Height)}
                }
                $bitmap.Save((Join-Path $out "$id.png"),[System.Drawing.Imaging.ImageFormat]::Png)
                $brush.Dispose(); $font.Dispose(); $g.Dispose(); $bitmap.Dispose()
                $cases.Add(@{id=$id;language=$lang;font=$family;font_px=$px;theme=$theme;layout='single';lines=$lines})
            }
        }
    }
}
foreach ($theme in @('light','dark')) {
    $id = "mixed_columns_18_$theme"
    $bitmap=[System.Drawing.Bitmap]::new(960,320); $bitmap.SetResolution(96,96)
    $g=[System.Drawing.Graphics]::FromImage($bitmap)
    $g.Clear([System.Drawing.ColorTranslator]::FromHtml($(if ($theme -eq 'light') {'#FAFAFA'} else {'#202124'})))
    $g.TextRenderingHint=[System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $font=[System.Drawing.Font]::new('Segoe UI',18,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
    $brush=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml($(if ($theme -eq 'light') {'#202124'} else {'#E8EAED'})))
    $lines=@()
    foreach ($column in @(0,1)) {
        for ($row=0;$row -lt 4;$row++) {
            $text=if ($column -eq 0) {@('Первая колонка ONE','Вторая строка TWO','Третья строка THREE','Четвёртая строка FOUR')[$row]} else {@('FIVE пятая строка','SIX шестая строка','SEVEN седьмая строка','EIGHT восьмая строка')[$row]}
            $x=24+$column*480; $y=24+$row*60
            $size=$g.MeasureString($text,$font,450,[System.Drawing.StringFormat]::GenericTypographic)
            $g.DrawString($text,$font,$brush,[System.Drawing.PointF]::new($x,$y),[System.Drawing.StringFormat]::GenericTypographic)
            $lines+=@{text=$text;box=@($x,$y,[double]$size.Width,[double]$size.Height)}
        }
    }
    $bitmap.Save((Join-Path $out "$id.png"),[System.Drawing.Imaging.ImageFormat]::Png)
    $brush.Dispose();$font.Dispose();$g.Dispose();$bitmap.Dispose()
    $cases.Add(@{id=$id;language='mixed';font='Segoe UI';font_px=18;theme=$theme;layout='columns';lines=$lines})
}
$cases | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'manifest.json') -Encoding utf8
Write-Output "Generated $($cases.Count) synthetic PNGs; no screen or clipboard access."
