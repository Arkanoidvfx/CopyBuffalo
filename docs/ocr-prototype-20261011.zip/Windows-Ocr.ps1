param([Parameter(Mandatory=$true)][string]$Image, [string]$Language='ru-RU', [int]$Repeats=5)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null=[Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null=[Windows.Storage.Streams.IRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime]
$null=[Windows.Media.Ocr.OcrResult,Windows.Foundation,ContentType=WindowsRuntime]
$null=[Windows.Globalization.Language,Windows.Globalization,ContentType=WindowsRuntime]
$asTask=[System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {$_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'} | Select-Object -First 1
function Await($operation,[type]$type) {
    $task=$asTask.MakeGenericMethod($type).Invoke($null,@($operation))
    $task.GetAwaiter().GetResult()
}
function Memory {
    $p=[System.Diagnostics.Process]::GetCurrentProcess();$p.Refresh()
    @{working_set=$p.WorkingSet64;private_bytes=$p.PrivateMemorySize64;peak_working_set=$p.PeakWorkingSet64}
}
$load=[System.Diagnostics.Stopwatch]::StartNew()
$before=Memory
$lang=[Windows.Globalization.Language]::new($Language)
$engine=[Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
if ($null -eq $engine) { throw "Windows OCR language unavailable: $Language" }
$load.Stop()
@{stage='load';ms=$load.Elapsed.TotalMilliseconds;language=$engine.RecognizerLanguage.LanguageTag;available=@([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages | ForEach-Object LanguageTag);before=$before;memory=(Memory)} | ConvertTo-Json -Depth 5 -Compress | Write-Output
for ($i=0;$i -lt $Repeats;$i++) {
    $watch=[System.Diagnostics.Stopwatch]::StartNew()
    $file=Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Image)) ([Windows.Storage.StorageFile])
    $stream=Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder=Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap=Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $decoded=$watch.Elapsed.TotalMilliseconds
    $result=Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $watch.Stop()
    $lines=@($result.Lines | ForEach-Object {
        $words=@($_.Words)
        $x=($words.BoundingRect.X | Measure-Object -Minimum).Minimum
        $y=($words.BoundingRect.Y | Measure-Object -Minimum).Minimum
        $right=($words | ForEach-Object {$_.BoundingRect.X+$_.BoundingRect.Width} | Measure-Object -Maximum).Maximum
        $bottom=($words | ForEach-Object {$_.BoundingRect.Y+$_.BoundingRect.Height} | Measure-Object -Maximum).Maximum
        @{text=$_.Text;box=@($x,$y,($right-$x),($bottom-$y));words=@($words | ForEach-Object {
            @{text=$_.Text;box=@($_.BoundingRect.X,$_.BoundingRect.Y,$_.BoundingRect.Width,$_.BoundingRect.Height)}
        })}
    })
    @{stage='run';iteration=$i;ms=$watch.Elapsed.TotalMilliseconds;decode_ms=$decoded;lines=$lines;memory=(Memory)} | ConvertTo-Json -Depth 6 -Compress | Write-Output
    $bitmap.Dispose();$stream.Dispose()
}
