"""Geometry-based line matching plus exact, case-sensitive Unicode CER and order errors."""
import csv
import json
from pathlib import Path
import re
import statistics
import unicodedata

ROOT = Path(__file__).resolve().parent

def normalized(text):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", text)).strip()

def edits(reference, actual):
    previous = [(i, i, 0, 0) for i in range(len(reference)+1)]
    for j, ac in enumerate(actual, 1):
        current = [(j, 0, j, 0)]
        for i, rc in enumerate(reference, 1):
            d, deletes, inserts, substitutes = previous[i-1]
            diagonal = (d+(rc != ac), deletes, inserts, substitutes+(rc != ac))
            d, deletes, inserts, substitutes = current[i-1]
            delete = (d+1, deletes+1, inserts, substitutes)
            d, deletes, inserts, substitutes = previous[i]
            insert = (d+1, deletes, inserts+1, substitutes)
            current.append(min((diagonal, delete, insert), key=lambda x: x[0]))
        previous = current
    return previous[-1]

def coverage(gt, detected):
    x,y,w,h = gt
    a,b,c,d = detected
    overlap = max(0,min(x+w,a+c)-max(x,a))*max(0,min(y+h,b+d)-max(y,b))
    return overlap/max(1,c*d)

def score(case, lines):
    grouped = [[] for _ in case["lines"]]
    order, unmatched = [], []
    for line in (part for region in lines for part in region.get("words",[region])):
        overlaps = [coverage(gt["box"], line["box"]) for gt in case["lines"]]
        idx = max(range(len(overlaps)), key=overlaps.__getitem__)
        if overlaps[idx] >= 0.35:
            grouped[idx].append(line)
            if not order or order[-1] != idx:
                order.append(idx)
        else:
            unmatched.append(line["text"])
    ref = normalized(" ".join(line["text"] for line in case["lines"]))
    actual = normalized(" ".join(line["text"] for line in lines))
    distance, deletes, inserts, substitutions = edits(ref, actual)
    content_errors = content_deletions = content_insertions = content_substitutions = 0
    word_deletions = expected_words = content_chars = exact = 0
    for gt, parts in zip(case["lines"],grouped):
        parts.sort(key=lambda p:p["box"][0])
        line_actual = normalized(" ".join(p["text"] for p in parts))
        line_ref = normalized(gt["text"])
        errors, removed, added, replaced = edits(line_ref,line_actual)
        content_errors += errors
        content_deletions += removed
        content_insertions += added
        content_substitutions += replaced
        content_chars += len(line_ref)
        word_deletions += edits(line_ref.split(),line_actual.split())[1]
        expected_words += len(line_ref.split())
        exact += line_ref == line_actual
    inversions = sum(order[i] > order[j] for i in range(len(order)) for j in range(i+1,len(order)))
    return {"reference_chars":len(ref), "errors":distance, "cer":distance/len(ref),
            "character_accuracy":max(0,1-distance/len(ref)), "deletions":deletes,
            "insertions":inserts, "substitutions":substitutions,
            "content_cer":content_errors/content_chars, "content_errors":content_errors,
            "content_chars":content_chars, "content_deletions":content_deletions,
            "content_insertions":content_insertions, "content_substitutions":content_substitutions,
            "word_deletions":word_deletions, "expected_words":expected_words,
            "missing_lines":sum(not p for p in grouped), "exact_lines":exact,
            "expected_lines":len(grouped), "returned_regions":len(lines),
            "order":order, "order_inversions":inversions, "unmatched_regions":unmatched,
            "reference":ref, "actual":actual}

def selftest():
    assert edits("abc", "abc") == (0,0,0,0)
    assert edits("abc", "ac") == (1,1,0,0)
    assert edits("abc", "abxc") == (1,0,1,0)
    assert edits("abc", "axc") == (1,0,0,1)
    case={"lines":[{"text":"one", "box":[0,0,30,20]},{"text":"two", "box":[0,40,30,20]}]}
    assert score(case, case["lines"])["cer"] == 0
    assert score(case, list(reversed(case["lines"])))["order_inversions"] == 1
    assert score(case, case["lines"][:1])["missing_lines"] == 1
    merged=[{"text":"one two","box":[0,0,30,60],"words":case["lines"]}]
    assert score(case,merged)["content_cer"] == 0
    assert score(case,merged)["missing_lines"] == 0

def main():
    selftest()
    manifest={c["id"]:c for c in json.loads((ROOT/"corpus/manifest.json").read_text(encoding="utf-8-sig"))}
    rows=[]
    for engine in ("windows","pure"):
        path=ROOT/"results"/f"{engine}.json"
        if not path.exists():
            continue
        for result in json.loads(path.read_text(encoding="utf-8")):
            if not result["valid"]:
                continue
            case=manifest[result["id"]]
            runs=[r for r in result["records"] if r["stage"]=="run"]
            load=next(r for r in result["records"] if r["stage"]=="load")
            row={k:case[k] for k in ("id","language","font","font_px","theme","layout")}
            row.update(score(case,runs[0]["lines"]))
            row.update(engine=engine,load_ms=load["ms"],first_ms=runs[0]["ms"],
                       startup_first_ms=runs[0]["process_elapsed_ms"],
                       warm_ms=[r["ms"] for r in runs[1:]],
                       warm_median_ms=statistics.median(r["ms"] for r in runs[1:]),
                       peak_rss_mib=result["peak_working_set"]/1048576,
                       peak_private_mib=result["peak_private_sampled"]/1048576,
                       stable=all(r["lines"]==runs[0]["lines"] for r in runs[1:]))
            rows.append(row)
    (ROOT/"results/scored.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf-8")
    fields=["engine","id","language","font","font_px","theme","layout","cer","content_cer",
            "missing_lines","exact_lines","expected_lines","content_deletions","word_deletions",
            "order_inversions","load_ms","first_ms","startup_first_ms","warm_median_ms",
            "peak_rss_mib","peak_private_mib","stable"]
    with (ROOT/"results/per-case.csv").open("w",encoding="utf-8-sig",newline="") as output:
        writer=csv.DictWriter(output,fieldnames=fields,extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    for engine in ("windows","pure"):
        items=[r for r in rows if r["engine"]==engine]
        if not items:
            continue
        total=sum(r["reference_chars"] for r in items)
        print(engine, json.dumps({"cases":len(items),"cer":sum(r["errors"] for r in items)/total,
              "missing_lines":sum(r["missing_lines"] for r in items),
              "exact_lines":sum(r["exact_lines"] for r in items),
              "expected_lines":sum(r["expected_lines"] for r in items),
              "inversions":sum(r["order_inversions"] for r in items),
              "first_median_ms":statistics.median(r["first_ms"] for r in items),
              "warm_median_ms":statistics.median(t for r in items for t in r["warm_ms"]),
              "load_median_ms":statistics.median(r["load_ms"] for r in items),
              "startup_first_median_ms":statistics.median(r["startup_first_ms"] for r in items),
              "max_peak_rss_mib":max(r["peak_rss_mib"] for r in items),
              "max_peak_private_mib":max(r["peak_private_mib"] for r in items),
              "stable":all(r["stable"] for r in items)},ensure_ascii=False))

if __name__=="__main__":
    main()
