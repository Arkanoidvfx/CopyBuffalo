use pure_onnx_ocr::{OcrEngineBuilder, RecDictionary};
use serde_json::json;
use std::{env, time::Instant};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 6 { return Err("usage: probe DET_DIR REC_DIR IMAGE THREADS REPEATS".into()); }
    let threads: usize = args[4].parse()?;
    let repeats: usize = args[5].parse()?;
    if threads == 0 || threads > 16 || repeats == 0 { return Err("invalid threads/repeats".into()); }
    println!("{}", json!({"stage":"start"}));
    let load = Instant::now();
    let engine = OcrEngineBuilder::new()
        .det_model_dir(&args[1])
        .rec_model_dir(&args[2])
        .inference_threads(threads)
        .rec_batch_size(1)
        .build()?;
    let load_ms = load.elapsed().as_secs_f64()*1000.0;
    let dictionary = RecDictionary::from_inference_yml(std::path::Path::new(&args[2]).join("inference.yml"))?.with_space_char();
    for ch in "АЯаяЁёЪъЫыABCxyz0129".chars() {
        if dictionary.index_of(&ch.to_string()).is_none() { return Err(format!("dictionary missing {ch}").into()); }
    }
    println!("{}", json!({"stage":"load","ms":load_ms,"threads":threads,"dictionary_classes":dictionary.len()}));
    for iteration in 0..repeats {
        let start = Instant::now();
        let results = engine.run_from_path(&args[3])?;
        let ms = start.elapsed().as_secs_f64()*1000.0;
        let lines: Vec<_> = results.iter().map(|r| {
            let points: Vec<_> = r.bounding_box.exterior().points().map(|p| [p.x(),p.y()]).collect();
            let min_x = points.iter().map(|p|p[0]).fold(f64::INFINITY,f64::min);
            let min_y = points.iter().map(|p|p[1]).fold(f64::INFINITY,f64::min);
            let max_x = points.iter().map(|p|p[0]).fold(f64::NEG_INFINITY,f64::max);
            let max_y = points.iter().map(|p|p[1]).fold(f64::NEG_INFINITY,f64::max);
            json!({"text":r.text,"confidence":r.confidence,"box":[min_x,min_y,max_x-min_x,max_y-min_y],"polygon":points})
        }).collect();
        println!("{}", json!({"stage":"run","iteration":iteration,"ms":ms,"lines":lines}));
    }
    Ok(())
}
