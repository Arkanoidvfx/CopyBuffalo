$ErrorActionPreference='Stop'
$studyPath=$PSScriptRoot
$env:CARGO_HOME=Join-Path $studyPath 'cargo-home'
$env:CARGO_TARGET_DIR=Join-Path $studyPath 'target'
$env:TEMP=Join-Path $studyPath 'temp';$env:TMP=$env:TEMP
New-Item -ItemType Directory -Path $env:TEMP -Force | Out-Null
[System.Diagnostics.Process]::GetCurrentProcess().PriorityClass='BelowNormal'
Get-PSDrive -PSProvider FileSystem | Select-Object Name,@{Name='FreeGB';Expression={[math]::Round($_.Free/1GB,1)}} | Format-Table -AutoSize
& nvidia-smi --query-gpu=name,memory.total,memory.used,memory.free,utilization.gpu --format=csv,noheader,nounits
& nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv,noheader,nounits
$revision='59a6c2c33c72e4dc8e7e5500f544d6674b0e6643'
$vendor=Join-Path $studyPath "vendor\pure-onnx-ocr-$revision"
if (-not (Test-Path -LiteralPath (Join-Path $vendor 'Cargo.toml'))) {
    Invoke-WebRequest -Uri "https://github.com/siska-tech/pure-onnx-ocr/archive/$revision.zip" -OutFile (Join-Path $studyPath 'upstream.zip')
    if ((Get-FileHash -LiteralPath (Join-Path $studyPath 'upstream.zip') -Algorithm SHA256).Hash -ne '69E8B03FD0600EAE1A959E0C18F23F7EA9F8A4175F708918BF0789996EF79188') {throw 'Upstream archive checksum mismatch'}
    Expand-Archive -LiteralPath (Join-Path $studyPath 'upstream.zip') -DestinationPath (Join-Path $studyPath 'vendor')
}
$models=@(
    @('det','PP-OCRv5_mobile_det_onnx','e6f4fa85f00e168c862bc462aebca69eef9b3d3d','A431985659DC921974177A95ADCFBB90FD9E51989A5E04D70D0B75F597B6E61D','98069072E1B6B37D727FD9D9F11725FAA46D6EA0DE012F2ED26CAEA011C37699'),
    @('rec','cyrillic_PP-OCRv5_mobile_rec_onnx','2cef88145434beb8afa9dd82d77d799eb1ad7b29','5371EE1DDAA7983CC62D0818D99E982B6804638C85E4F960D59A574094E172E5','5C76CC91FA98410178A09F498DB10050D0EC1634A660053D3005AB7BE581F501')
)
foreach ($model in $models) {
    $dir=Join-Path $studyPath "models\$($model[0])"
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $files=@('inference.onnx','inference.yml')
    for ($i=0;$i -lt 2;$i++) {
        $path=Join-Path $dir $files[$i]
        if (-not (Test-Path -LiteralPath $path)) {
            Invoke-WebRequest -Uri "https://huggingface.co/PaddlePaddle/$($model[1])/resolve/$($model[2])/$($files[$i])" -OutFile $path
        }
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $model[$i+3]) {throw "Model checksum mismatch: $path"}
    }
}
& cargo build --release --locked --jobs 2 --manifest-path (Join-Path $studyPath 'probe\Cargo.toml') *> (Join-Path $studyPath 'build.log')
$buildExit=$LASTEXITCODE
Select-String -LiteralPath (Join-Path $studyPath 'build.log') -Pattern '^error|error\[|failed|Finished' -Context 1,3
if ($buildExit -ne 0) {throw "Cargo failed: $buildExit"}
