"""Local-only Windows runner; stdlib, explicit corpus paths, hidden child processes."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import random
import subprocess
import threading
import time
from ctypes import wintypes

ROOT = Path(__file__).resolve().parent

class MemoryCounters(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in (
            "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
            "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
            "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage", "PrivateUsage")]

psapi = ctypes.WinDLL("psapi", use_last_error=True)
kernel = ctypes.WinDLL("kernel32", use_last_error=True)
psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(MemoryCounters), wintypes.DWORD]
kernel.SetProcessAffinityMask.argtypes = [wintypes.HANDLE, ctypes.c_size_t]

def memory(handle):
    data = MemoryCounters()
    data.cb = ctypes.sizeof(data)
    if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(data), data.cb):
        return None
    return {"working_set": data.WorkingSetSize, "peak_working_set": data.PeakWorkingSetSize,
            "private_bytes": data.PrivateUsage}

def run_case(case, engine, repeats):
    image = ROOT / "corpus" / (case["id"] + ".png")
    assert image.parent == ROOT / "corpus" and image.is_file()
    if engine == "pure":
        command = [str(ROOT / "target/release/copybuffalo-ocr-probe.exe"),
                   str(ROOT / "models/det"), str(ROOT / "models/rec"), str(image), "4", str(repeats)]
    else:
        command = [str(Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"),
                   "-NoProfile", "-NonInteractive", "-File", str(ROOT / "Windows-Ocr.ps1"),
                   "-Image", str(image), "-Language", "en-US" if case["language"] == "en" else "ru-RU",
                   "-Repeats", str(repeats)]
    log = ROOT / "results" / f"{engine}_{case['id']}.stderr.txt"
    records, output = [], []
    started = time.perf_counter()
    with log.open("wb") as stderr:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=stderr,
                                   creationflags=0x08000000 | 0x00004000)
        handle = wintypes.HANDLE(int(process._handle))
        if not kernel.SetProcessAffinityMask(handle, 0xF000):
            process.kill()
            raise ctypes.WinError(ctypes.get_last_error())
        def read_output():
            for line in process.stdout:
                output.append(line.decode("utf-8", errors="replace"))
                try:
                    item = json.loads(output[-1])
                    item["process_elapsed_ms"] = (time.perf_counter() - started) * 1000
                    item["sampled_memory"] = memory(handle)
                    records.append(item)
                except (ValueError, TypeError):
                    pass
        reader = threading.Thread(target=read_output, daemon=True)
        reader.start()
        samples = []
        while process.poll() is None:
            sample = memory(handle)
            if sample:
                samples.append(sample)
            if time.perf_counter() - started > 300:
                process.kill()
                process.wait()
                break
            time.sleep(0.02)
        reader.join(timeout=5)
        code = process.wait()
    samples.extend(r["sampled_memory"] for r in records if r.get("sampled_memory"))
    samples.extend(r["memory"] for r in records if r.get("memory"))
    peak_rss = max((s["peak_working_set"] for s in samples), default=0)
    peak_private = max((s["private_bytes"] for s in samples), default=0)
    valid = code == 0 and len([r for r in records if r.get("stage") == "run"]) == repeats
    return {"id": case["id"], "engine": engine, "exit_code": code, "valid": valid,
            "process_total_ms": (time.perf_counter() - started) * 1000,
            "peak_working_set": peak_rss, "peak_private_sampled": peak_private,
            "records": records, "stdout": "".join(output),
            "error": "" if valid else log.read_text(encoding="utf-8", errors="replace")[:4000]}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--engine", choices=["pure", "windows", "both"], required=True)
    parser.add_argument("--filter", default="")
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()
    if not 2 <= args.repeats <= 20:
        parser.error("repeats must be 2..20")
    manifest = json.loads((ROOT / "corpus/manifest.json").read_text(encoding="utf-8-sig"))
    cases = [c for c in manifest if args.filter in c["id"]]
    if not cases:
        parser.error("no matching corpus cases")
    (ROOT / "results").mkdir(exist_ok=True)
    engines = ["windows", "pure"] if args.engine == "both" else [args.engine]
    results = {engine: [] for engine in engines}
    random.Random(20261011).shuffle(cases)
    suffix = "_smoke" if args.filter else ""
    for index, case in enumerate(cases):
        for engine in engines if index % 2 == 0 else list(reversed(engines)):
            result = run_case(case, engine, args.repeats)
            results[engine].append(result)
            destination = ROOT / "results" / f"{engine}{suffix}.json"
            destination.write_text(json.dumps(results[engine], ensure_ascii=False, indent=2), encoding="utf-8")
            timings = [round(r["ms"], 1) for r in result["records"] if r.get("stage") == "run"]
            print(f"{index+1}/{len(cases)} {engine} {case['id']} valid={result['valid']} ms={timings}", flush=True)
            if not result["valid"]:
                print(result["error"], flush=True)
                raise SystemExit(1)

if __name__ == "__main__":
    main()
